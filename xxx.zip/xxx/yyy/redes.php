<?php include("template/cabecera.php");?>


<div class="jumbotron">
    <h1 class="display-4">INSTITUCIONES</h1>
    <p class="lead">(TECNM)</p>
   
    <hr class="my-2">
     <p class="lead"></p> <a name="" id="" class="btn btn-primary" href="informatica.php" role="button">PLANTEL IZTAPALAPA</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL TLAHUAC</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL TLALPAN</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL CHURUBUSCO</a>

     <hr class="my-2">
     <p class="lead"></p><a name="" id="" class="btn btn-primary" href="" role="button">PLANTEL SANTA FE</a>

 </div>
 
    
 </div>

<?php include("template/pie.php"); ?>
